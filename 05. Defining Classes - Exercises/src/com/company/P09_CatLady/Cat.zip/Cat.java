package com.company.P09_CatLady;

public class Cat {
    private String name;

    public Cat(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
class Siamese extends Cat {
    private double earSize;

    public Siamese(String name, double earSize) {
        super(name);
        this.earSize = earSize;
    }

    @Override
    public String toString() {
        return String.format("Siamese %s %.2f",super.getName(), this.earSize);
    }
}
class Cymric extends Cat {
    private double furLength;

    public Cymric (String name, double furLength) {
        super(name);
        this.furLength = furLength;
    }
    @Override
    public String toString() {
        return String.format("Cymric %s %.2f",super.getName(), this.furLength);
    }
}

class StreetExtraordinaire extends Cat {
    private double decibelsOfMeows;

    public StreetExtraordinaire (String name, double decibelsOfMeows) {
        super(name);
        this.decibelsOfMeows = decibelsOfMeows;
    }
    @Override
    public String toString() {
        return String.format("StreetExtraordinaire %s %.2f",super.getName(), this.decibelsOfMeows);
    }
}

